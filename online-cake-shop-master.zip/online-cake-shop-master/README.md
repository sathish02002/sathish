# online-cake-shop
1. (required to download xampp) save folder(onlinecakeshop) in htdocs folder inside xampp
2. create database with name onlinecakeshop
3. import onlinecakeshop.sql in database
4. url to use `localhost/onlinecakeshop` for user-side & `localhost/onlinecakeshop/admin` for admin-side
5. login username and password can be found in database
