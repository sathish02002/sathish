<?php
$host = "localhost";
$config_username = "root";
$password = "";
$db = "onlinecakeshop";
$conn = mysqli_connect($host, $config_username, $password, $db);
?>