<?php
include "config.php";
if(isset($_POST['input'])){
    
$input=$_POST['input'];
$query="SELECT * FROM `users` where `email` LIKE '%{$input}%'";
$result=mysqli_query($conn,$query);
if(mysqli_num_rows($result)>0){
    ?>

    <table class="table table-border table-striped mt-4">
        <thead>
            <tr>
                <th>id</th>
                <th>email</th>
                <th>password</th>
                <th>date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            
            while($row=mysqli_fetch_assoc($result)){
                $id=$row['id'];
                $email=$row['email'];
                $password=$row['password'];
                $date=$row['date'];
                ?>
                    <tr>
                        <td><?php  echo $id; ?></td>
                        <td><?php  echo $email; ?></td>
                        <td><?php  echo $password; ?></td>
                        <td><?php  echo $date; ?></td>
                    </tr>
                <?php
            }
            ?>
        </tbody>

    </table>
<?php
}
else{
    echo "<h1 class='text-danger text-center'>No Data Found</h1>";
}
}

?>