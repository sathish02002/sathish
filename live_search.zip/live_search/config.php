<?php


$conn=mysqli_connect("localhost","root","","forgot_db");



?>