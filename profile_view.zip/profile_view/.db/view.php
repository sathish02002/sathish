<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <h1 class="text-center ">Status(active,deactive)</h1>
        <?php
    include "config.php";
    $result=mysqli_query($connection,"select * from `users`");
    
    ?>
    <table class="table mt-5">
   <tr>
    <th>Id</th>
    <th>User name</th>
    <th>Email</th>
   
    <th>Change status</th>
   </tr>
   <?php
   while($row=mysqli_fetch_assoc($result)){

    ?>
   <tr>
    <td><?php echo $row['id']; ?>.</td>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php
    if($row['status']==1){
        echo "<a class='btn btn-success' href='status.php?id=".$row['id']."&status=0'>Active</a>";
    }
    else{
        echo "<a class='btn btn-danger' href='status.php?id=".$row['id']."&status=1'>Deactive</a>";


    }
    ?></td>
  
    
   </tr>
<?php
}
?>
</table>
        </div>
        <div class="col-md-3"></div>
    </div>
  
</body>
</html>