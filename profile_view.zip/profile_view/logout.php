<?php  
session_start();

session_unset();

if(session_destroy())
echo "<script>confirm('are you sure logout');</script>";
echo "<script>location.replace('login.php');</script>";

exit;