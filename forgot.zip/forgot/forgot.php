<?php 
session_start();
$error = array();

require "mail.php";

	if(!$con = mysqli_connect("localhost","root","","forgot_db")){

		die("could not connect");
	}

	$mode = "enter_email";
	if(isset($_GET['mode'])){
		$mode = $_GET['mode'];
	}

	//something is posted
	if(count($_POST) > 0){

		switch ($mode) {
			case 'enter_email':
				// code...
				$email = $_POST['email'];
				//validate email
				if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
					$error[] = "Please enter a valid email";
				}elseif(!valid_email($email)){
					$error[] = "That email was not found";
				}else{

					$_SESSION['forgot']['email'] = $email;
					send_email($email);
					header("Location: forgot.php?mode=enter_code");
					die;
				}
				break;

			case 'enter_code':
				// code...
				$code = $_POST['code'];
				$result = is_code_correct($code);

				if($result == "the code is correct"){

					$_SESSION['forgot']['code'] = $code;
					header("Location: forgot.php?mode=enter_password");
					die;
				}else{
					$error[] = $result;
				}
				break;

			case 'enter_password':
				// code...
				$password = $_POST['password'];
				$password2 = $_POST['password2'];

				if($password !== $password2){
					$error[] = "Passwords do not match";
				}elseif(!isset($_SESSION['forgot']['email']) || !isset($_SESSION['forgot']['code'])){
					header("Location: forgot.php");
					die;
				}else{
					
					save_password($password);
					if(isset($_SESSION['forgot'])){
						unset($_SESSION['forgot']);
					}

					header("Location: login.php");
					die;
				}
				break;
			
			default:
				// code...
				break;
		}
	}

	function send_email($email){
		
		global $con;

		$expire = time() + (60 * 1);
		
		$code = rand(000000,999999);
		$email = addslashes($email);

		// $query = "insert into codes (email,code,expire) value ('$email','$code','$expire')";

		$query="UPDATE `codes` SET `code`='$code',`expire`='$expire' WHERE `email` = '$email' LIMIT 1";

		// $query = "update codes set code = '$code' expire='$expire' where email = '$email' limit 1";
		$res=mysqli_query($con,$query);
		// $row=mysqli_fetch_assoc($res);
	
		// $result=mysqli_query($con,$query1);

		

		//send email here
		send_mail($email,'Password reset',"Your code is " . $code);
	}
	
	function save_password($password){
		
		global $con;

		$password = $password;
		$email = addslashes($_SESSION['forgot']['email']);

		$query = "update users set password = '$password' where email = '$email' limit 1";
		mysqli_query($con,$query);

	}
	
	function valid_email($email){
		global $con;

		$email = addslashes($email);

		$query = "select * from users where email = '$email' limit 1";		
		$result = mysqli_query($con,$query);
		if($result){
			if(mysqli_num_rows($result) > 0)
			{
				return true;
 			}
		}

		return false;

	}

	function is_code_correct($code){
		global $con;

		$code = addslashes($code);
		$expire = time();
		$email = addslashes($_SESSION['forgot']['email']);

		$query = "select * from codes where code = '$code' && email = '$email' order by id desc limit 1";
		$result = mysqli_query($con,$query);
		if($result){
			if(mysqli_num_rows($result) > 0)
			{
				$row = mysqli_fetch_assoc($result);
				if($row['expire'] > $expire){

					return "the code is correct";
				}else{
					return "the code is expired";
				}
			}
			else{
				return "the code is incorrect";
			}
		}

		return "the code is incorrect";
	}

	
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Forgot</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<!-- <style type="text/css">
	
	*{
		font-family: tahoma;
		font-size: 13px;
	}

	form{
		width: 100%;
		max-width: 200px;
		margin: auto;
		border: solid thin #ccc;
		padding: 10px;
	}

	.textbox{
		padding: 5px;
		width: 180px;
	}
</style> -->

		<?php 

			switch ($mode) {
				case 'enter_email':
					
					?>
					<div class="row">
						<div class="col-md-4"></div>
						<div class="col-md-4 mt-5">
						<form method="post" class="form-control" action="forgot.php?mode=enter_email"> 
							<h1 class="text-center">Forgot Password</h1>
							<h3 class="text-center">Enter your email below</h3>
							<span style="font-size: 12px;color:red;">
							<?php 
								foreach ($error as $err) {
									
									echo $err . "<br>";
								}
							?>
							</span>
							<input  class="form-control" type="email" name="email" placeholder="Email"><br>
							<!-- <br style="clear: both;"> -->
							<input type="submit" class="btn btn-success" id="empty" value="Next">
							<br><br>
							<div><a href="login.php">Login</a></div>
						</form>
						</div>
						<div class="col-md-4"></div>
					</div>
				
					<?php				
					break;

				case 'enter_code':
					
					?>
					<div class="row">
						<div class="col-md-4"></div>
						<div class="col-md-4 mt-5">
						<form method="post" action="forgot.php?mode=enter_code"> 
							<h1 class="text-center">Forgot Password</h1>
							<h3 class="text-center">Enter your the code sent to your email</h3>
							<!-- <span style="font-size: 12px;color:red;"> -->
							<?php 
								foreach ($error as $err) {
								
									echo $err . "<br>";
								}
							?>
							</span>
							<?php
							// $expire = second() + (15 * 1);
							// echo $expire;
							;?>
							<h3 class="text-center">OTP expired time <small id="timer">00:00</small></h3>
							<input  class="form-control" type="text" name="code" placeholder="12345"><br>
							
							<input type="submit" class="form-control" value="Next" style="float: right;">
							<a href="forgot.php">
								<input type="button" class="btn btn-success" value="Start Over">
							</a>
							<br><br>
							<div><a href="login.php">Login</a></div>
						</form>
						</div>
						<div class="col-md-4"></div>
					</div>
					
					<?php
					break;

				case 'enter_password':
				
					?>
						<div class="row">
						<div class="col-md-4"></div>
						<div class="col-md-4 mt-5">
						<form method="post" class="form-control" action="forgot.php?mode=enter_password"> 
							<h1 class="text-center">Forgot Password</h1>
							<h3 class="text-center">Enter your new password</h3>
							<span style="font-size: 12px;color:red;">
							<?php 
								foreach ($error as $err) {
									
									echo $err . "<br>";
								}
							?>
							</span>

							<input  class="form-control" type="text" name="password" placeholder="Password"><br>
							<input  class="form-control" type="text" name="password2" placeholder="Retype Password"><br>
							
							<input type="submit" class="btn btn-success" value="Next" style="float: right;">
							<a href="forgot.php">
								<input type="button" class="btn btn-success"  value="Start Over">
							</a>
							<br><br>
							<div><a href="login.php">Login</a></div>
						</form>
						</div>
						<div class="col-md-4"></div>
					</div>
						
					<?php
					break;
				
				default:
					// code...
					break;
			}

		?>
		 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		 <script>
        $(document).ready(function() {
            var duration = 30; // Duration of the OTP timer in seconds
            var timerDisplay = $('#timer');
			var empty=$('#empty').val();
            // Function to update the timer
            function updateTimer() {
                var minutes = Math.floor(duration / 60);
                var seconds = duration % 60;

                // Add leading zeros to minutes and seconds
                var formattedTime = ("0" + seconds).slice(-2);

                // Display the formatted time
                timerDisplay.text(formattedTime);

                if (duration <= 0) {
                    // Timer has expired
                    clearInterval(timerInterval);
                    timerDisplay.text("OTP Expired");
					// timerDisplay.close();
                }
				else if(empty==""){
					timerDisplay.text("the code is incorrect")

				}
				 else {
                    duration--; // Decrease the duration by 1 second
                }
            }

            // Start the timer
            var timerInterval = setInterval(updateTimer, 1000);
        });
    </script>


</body>
</html>