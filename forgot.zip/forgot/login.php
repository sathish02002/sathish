

<?php

// Assuming you already have a database connection established


$conn = new mysqli("localhost", "root", "", "forgot_db");


// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the username and password from the form
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Prepare and execute the SQL query
    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // User is authenticated
        // Redirect to the dashboard or homepage after successful login
        header("Location: index.php");
        exit();
    } else {
        // Display an error message if the login credentials are incorrect
        echo "Invalid username or password.";
    }
}

// Close the database connection
$conn->close();
?>





<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
    <form method="post" class="form-control"> 
		<h1 class="text-center">Login</h1>
		<input type="email" class="form-control" name="email" placeholder="Email"><br>
		<input type="text" class="form-control" name="password" placeholder="Password"><br>
	
		<input type="submit" class="btn btn-success" value="Login">
		<br><br>
		<div><a href="forgot.php">Forgot password?</a></div>
		<div><a href="registration.php">Create New Account</a></div>
	</form>
    </div>
    <div class="col-md-4"></div>
</div>

</body>
</html>