
<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
        <h2 class="text-center">Registration Form</h2>
    <form action="registration.php" class="form-control" method="POST">
       
        <input type="email" class="form-control" name="email" placeholder="Email" values="    <?php  if(isset($_POST['email'])){
           
           $email = $_POST['email'];
           echo $email;
       }
       ?>"><br><br>

        
        <input type="password" class="form-control" placeholder="password" name="password" value=""<?php 
     
        ?> ><br><br>

        
        <input type="date" class="form-control" placeholder="" name="date" ><br><br>

        <input type="submit" class="btn btn-success" name="submit" value="Register">
							<div><a href="login.php" class="link link-info mt-5">Already you have account</a></div>

    </form>
    <?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "forgot_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['submit'])){

// Retrieve form data
$email = $_POST['email'];
$password = $_POST['password'];
$date = $_POST['date'];
$errors=array();

if(empty($email||$password||$date)){
    // die("please fill required");
    array_push($errors,"please fill required");
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    // die("Invalid email format");
    array_push($errors,"Invalid email format");

}

if (strlen($password) < 6) {
    // die("Password must be at least 6 characters long");
    array_push($errors,"pPassword must be at least 6 characters long");
}
$query="SELECT * FROM `users` WHERE `email`='$email'";
$resul=mysqli_query($conn,$query);
$row=mysqli_num_rows($resul);
if($row==1){
// Prepare and execute the SQL INSERT statement
array_push($errors,"Email Already exist");


}

if (count($errors) > 0) {
    foreach ($errors as $error) {
        
        echo "<div class='alert alert-danger'>$error</div>";


    } }
    
    else {  
          $sql = "INSERT INTO users (email, password, date) VALUES ('$email', '$password', '$date')";
$sql1 = "INSERT INTO codes (email) VALUES ('$email')";
mysqli_query($conn,$sql1);
        if (mysqli_query($conn, $sql)) {
    echo "Registration successful";

}
}
}


// Close the database connection
mysqli_close($conn);
?>
        </div>
        <div class="col-md-3"></div>
    </div>
  
</body>
</html>


