<?php

	if(!$con = mysqli_connect("localhost","root","","forgot_db")){

		die("could not connect");
	}

/*	$password = password_hash('password', PASSWORD_DEFAULT);
	$query = "update users set password = '$password' ";
	mysqli_query($con,$query);
*/

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>

<h1>Home Page</h1>
<?php
?>
</body>
</html>