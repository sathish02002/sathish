<!DOCTYPE html>
<html>
<head>
    <title>OTP Timer</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h2>OTP Timer</h2>
    <p id="timer">00:00</p>

    <script>
        $(document).ready(function() {
            var duration = 20; // Duration of the OTP timer in seconds
            var timerDisplay = $('#timer');

            // Function to update the timer
            function updateTimer() {
                var minutes = Math.floor(duration / 60);
                var seconds = duration % 60;

                // Add leading zeros to minutes and seconds
                var formattedTime = ("0" + seconds).slice(-2);

                // Display the formatted time
                timerDisplay.text(formattedTime);

                if (duration <= 0) {
                    // Timer has expired
                    clearInterval(timerInterval);
                    timerDisplay.text("OTP Expired");
                } else {
                    duration--; // Decrease the duration by 1 second
                }
            }

            // Start the timer
            var timerInterval = setInterval(updateTimer, 1000);
        });
    </script>
</body>
</html>
