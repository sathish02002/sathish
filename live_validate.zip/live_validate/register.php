<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-5">
            <h1 class="text-center">Register form</h1>
        <?php
    
   
    include "config.php";
    if(isset($_POST['submit'])){
   
        $name=$_POST['name'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $mobile=$_POST['mobile'];
$errors=array();
// $error="";

include "config.php";
$sql1="SELECT*FROM`tables` where `email`='$email'";
$res=mysqli_query($conn,$sql1);
$rows=mysqli_fetch_assoc($res);
if($rows>0){
    array_push($errors,"email already registered");
}
include "config.php";
$sql2="SELECT*FROM`tables` where `mobile`='$mobile'";
$res1=mysqli_query($conn,$sql2);
$rows1=mysqli_fetch_assoc($res1);
if($rows1>0){
    array_push($errors,"mobile already registered");
}
        if (empty($name && $email && $password &&$mobile)) {
            array_push($errors, "please required all filed");
        
            } if ((!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8 || !preg_match("/^[6-9]{1}[0-9]{9}$/", $mobile))) {
                array_push($errors, "please fill correct");
              }
             
            if (count($errors) > 0) {
                foreach ($errors as $error) {
                    
                    echo "<div class='alert alert-danger'>$error</div>";
      

                } ?>


                <?php
                
            }
            else{
    $sql="insert into `tables`(`name`,`email`,`password`,`mobile`)values('$name','$email','$password','$mobile')";
    $result=mysqli_query($conn,$sql);

     if($result){
        echo "<div class='alert alert-success'>data inserted</div>";
    }else{
        echo "<div class='alert alert-danger'>data not inserted</div>";
    }
 }

   

 }
 
?>
        <form id="registrationForm"  class="form-control mt-5" method="post" action="register.php">
    <input type="text" id="name"  class="form-control mt-5" name="name" placeholder="Name">
    <span style="color:red;" id="nameError"><?php
   
    ?></span>
    
    <input type="email" id="email" class="form-control mt-5" name="email" placeholder="Email">
    <span  style="color:red;"id="emailError"></span>
    <input type="password" id="password" class="form-control mt-5" name="password" placeholder="Password">
    <span  style="color:red;" id="passwordError"></span>
    <input type="text" id="mobile" maxlenght="10" name="mobile" maxlength="10" class="form-control mt-5" placeholder="Mobile Number">
    <span  style="color:red;" id="mobileError"></span>
    
     <button type="submit" name="submit"  id="submit" class="btn btn-success form-control mt-3">Register</button>
    
</form>

       
     <?php


?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>

 $(document).ready(function() {
    // $('#name').keyup(function() {
    //     var name = $(this).val();
    //     if (name.length < 3) {
    //         $('#nameError').text('Name must be at least 3 characters long');
    //     } else {
    //         $('#nameError').text('');
    //     }
    // });
    $('')
       $('#name').keyup(function() {
        
        var name = $(this).val();
        if (!/^[a-z A-Z]+$/.test(name)) {
            $('#name').css('border-color', 'red');
            $('#nameError').text('Username should only contain letters and');
        } else if((name.length < 3||(name==""))) {
            $('#name').css('border-color', 'red');
            $('#nameError').text('Name must be at least 3 characters long');
        }
        // else if() {
        //     $('#name').css('border-color', 'red');
        //     // $('#nameError').text('please required');
        // }
        else{
            $('#nameError').text('');
            $('#name').css('border-color', 'green');
            
        }
    });

    $('#email').keyup(function() {
        var email = $(this).val();
        if (isValidEmail(email)) {
            $('#emailError').text('');
            $('#email').css('border-color', 'green');

        } 
        else if((email=="")) {
            $('#email').css('border-color', 'red');
            // $('#emailError').text('please required ');
        }
        else {
            $('#email').css('border-color', 'red');

            $('#emailError').text('Invalid email address');
        }
    });

    $('#password').keyup(function() {
        var password = $(this).val();
        if (password.length < 8) {
            $('#passwordError').text('Password must be at least 8 characters long');
            $('#password').css('border-color', 'red');

        } 
        else if((password=="")) {
            $('#passwordError').text('please required');
        }else {
            $('#password').css('border-color', 'green');
         
            $('#passwordError').text('');
        }
    });

    $('#mobile').keyup(function() {
        var mobile = $(this).val();
        if (!isValidMobile(mobile)) {
            $('#mobileError').text('Invalid mobile number');
            $('#mobile').css('border-color', 'red');

        }
        else if((mobile=="")) {
            $('#mobileError').text('please required');
        } else {
            $('#mobileError').text('');
            $('#mobile').css('border-color', 'green');

        }
    });

    function isValidEmail(email) {
        // Email validation logic (regular expression or other methods)
        // Return true if valid, false otherwise
        var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

return pattern.test(email);
    }

    function isValidMobile(mobile) {
        // Mobile number validation logic (regular expression or other methods)
        // Return true if valid, false otherwise
        var pattern = /^[6-9]{1}[0-9]{9}$/; // 10 digits only

return pattern.test(mobile);
    }
});

</script>

        </div>
        <div class="col-md-3"></div>
    </div>


</body>
</html>