<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <form id="register-form" method="post" class="form-control" action="register1.php">
    <input type="text" name="username" class="form-control" id="username" > 
    <span id="username-error" class="error"></span>
    <input type="email" name="email" class="form-control" id="email" > 
    <span id="email-error" class="error"></span>
    <!-- Other form fields -->

    <!-- Validation error messages -->
   
   
    <!-- Other error spans -->

    <input type="submit" name="submit" value="Register">
</form>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Live validation using jQuery
        $('#username').on('input', function() {
            validateUsername();
        });

        $('#email').on('input', function() {
            validateEmail();
        });

        function validateUsername() {
            var usernameInput = $('#username');
            var errorSpan = $('#username-error');
            var username = usernameInput.val().trim();

            // Perform validation checks using JavaScript
            if (username.length === 0) {
                errorSpan.text("Username is required.");
            } else {
                errorSpan.text("");
            }
        }

        function validateEmail() {
            var emailInput = $('#email');
            var errorSpan = $('#email-error');
            var email = emailInput.val().trim();

            // Perform validation checks using JavaScript
            if (email.length === 0) {
                errorSpan.text("Email is required.");
            } else {
                errorSpan.text("");
            }
        }

        // Form submission using AJAX
        $('#register-form').submit(function(event) {
            event.preventDefault(); // Prevent form submission

            $.ajax({
                url: 'register1.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    // Registration successful
                    alert(response.message);
                    $('#register-form')[0].reset();
                },
                error: function(xhr, status, error) {
                    // Form validation errors occurred
                    var errors = xhr.responseJSON;
                    displayValidationErrors(errors);
                }
            });
        });

        function displayValidationErrors(errors) {
            // Reset previous error messages
            $('.error').text("");

            // Display error messages for each field
            for (var field in errors) {
                if (errors.hasOwnProperty(field)) {
                    $('#' + field + '-error').text(errors[field]);
                }
            }
        }
    });
</script>
</body>
</html>
<?php
$errors = array();

if(isset($_POST['submit'])){
    // Retrieve form data and validate
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    // Other form fields...

    // Perform validation checks
    if (empty($username)) {
        $errors[] = "Username is required.";
    }
    if (empty($email)) {
        $errors[] = "Email is required.";
    }
    // Other validation checks...

    // If there are any errors, return them as JSON response
    if (!empty($errors)) {
        http_response_code(400); // Set appropriate status code
        echo json_encode($errors);
        exit;
    }

    // If the form data is valid, proceed to insert into the database
    // Connect to the database (replace with your own credentials)
    $servername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "db";

    $conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL INSERT statement
    $stmt = $conn->prepare("INSERT INTO `tables` (`name`, `email`) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();

    // Check if the insertion was successful
    if ($stmt->affected_rows > 0) {
        echo 'Registration successful.';
    } else {
        echo 'Error inserting data into the database.';
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
}
?>


</div>
        <div class="col-md-3"></div>
    </div>

