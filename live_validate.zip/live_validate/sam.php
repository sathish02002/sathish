
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form id="myForm" action="insert.php" method="POST">
  <input type="text" name="name" id="name" placeholder="Name" required>
  <span id="nameError" class="error"></span>
  
  <input type="email" name="email" id="email" placeholder="Email" required>
  <span id="emailError" class="error"></span>
  
  <input type="submit" value="Submit">
</form>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
  // Name field validation
  $('#name').on('input', function() {
    var name = $(this).val().trim();
    if (name === '') {
      $('#nameError').text('Name is required');
    } else {
      $('#nameError').text('');
    }
  });

  // Email field validation
  $('#email').on('input', function() {
    var email = $(this).val().trim();
    if (email === '') {
      $('#emailError').text('Email is required');
    } else if (!isValidEmail(email)) {
      $('#emailError').text('Invalid email format');
    } else {
      $('#emailError').text('');
    }
  });

  // Helper function to validate email format
  function isValidEmail(email) {
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // Form submission
  $('#myForm').submit(function(event) {
    event.preventDefault(); // Prevent the form from submitting normally

    // Validate the form fields
    var name = $('#name').val().trim();
    var email = $('#email').val().trim();

    if (name === '') {
      $('#nameError').text('Name is required');
    }

    if (email === '') {
      $('#emailError').text('Email is required');
    } else if (!isValidEmail(email)) {
      $('#emailError').text('Invalid email format');
    }

    // If form is valid, proceed to AJAX request or form submission
    if (name !== '' && email !== '' && isValidEmail(email)) {
      $.ajax({
        url: $(this).attr('action'), // Form action URL
        type: $(this).attr('method'), // Form submission method (POST)
        data: $(this).serialize(), // Serialize the form data
        success: function(response) {
          alert(response); // Display success message or handle it accordingly
          // Reset the form
          $('#myForm')[0].reset();
        }
      });
    }
  });
});
</script>

</body>
</html>
